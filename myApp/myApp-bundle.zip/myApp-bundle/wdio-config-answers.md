=========================
WDIO Configuration Helper
=========================

? Where do you want to execute your tests? On my local machine
? Which framework do you want to use? cucumber
? Shall I install the framework adapter for you? Yes
? Where are your feature files located? ./features/**/*.feature
? Where are your step definitions located? ./features/step-definitions/**/*.js
? Which reporter do you want to use? 
? Do you want to add a service to your test setup? 
? Level of logging verbosity: verbose
? In which directory should screenshots gets saved if a command fails? ./errorShots/
? What is the base url? http://localhost


